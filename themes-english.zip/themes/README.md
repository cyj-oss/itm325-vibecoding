# English Student Theme Pack

These five files are teaching adaptations of the instructor-supplied theme pack. They use familiar product references to help you compare visual styles. They are not official brand guidelines, and the course is not affiliated with the named brands.

## Choose one theme

| File | Visual direction |
| --- | --- |
| `apple.md` | Spacious, minimal, blue actions, pill buttons |
| `notion.md` | Warm, content-focused, flat surfaces, small corners |
| `doordash.md` | Energetic red, rounded cards, bold actions |
| `nextdoor.md` | Welcoming green, community feel, clear lists |
| `cash-app.md` | Vivid green with dark button text, large type, soft cards |

Use exactly one theme at a time. Every file has the same `name: design-theme` on purpose, because you are choosing one design manual for your project.

## Set up the selected theme

1. Unzip `themes-english.zip`. Put the entire `themes` folder in your project root, next to `package.json`. Keep these files as your theme library.
2. Choose one of the five theme files. Read its design direction before making your choice.
3. In your project, create `.claude/skills/design-theme/SKILL.md`. Keep the uppercase file name exactly as shown.
4. Copy the **entire contents** of your chosen theme file into `SKILL.md`, including the opening and closing `---` lines and the `name` and `description` fields. Do not combine multiple theme files or copy this README into the skill.
5. Start Claude Code in this project. Use `/skills` to check that `design-theme` appears. If it does not, exit Claude Code completely and start it again, then check the folder path and frontmatter.
6. Follow Lesson 7.3 and ask Claude to improve the design. For example: "Make the design look nicer." The selected manual gives that request a concrete visual direction.
7. Run the app with `npm run dev` and review the result. Check the layout, readable text, keyboard focus, forms, and existing behavior. Then follow the lesson's commit-and-push steps.

To switch themes later, replace the entire contents of the same `SKILL.md` with a different theme file, restart Claude Code, and request a consistent restyling. Do not register all five as active skills for the same styling task.

## What these adaptations change

- All student-facing instructions and examples are in English.
- The original regional delivery, neighborhood, and finance references are adapted to DoorDash, Nextdoor, and Cash App respectively. Apple and Notion remain recognizable references.
- Every theme uses light mode only. Conflicting dark palettes have been removed.
- Text colors, button colors, focus indicators, and control boundaries have been adjusted for readability. Body text and inputs are at least 16px.
- Instructions distinguish CSS visual states, browser event handlers in Client Components, and server-side operations.
- The files describe styling only. They do not add real payments, accounts, personal data, brand logos, or new app features.

Your finished app should retain its own project name, content, and working features. Use the theme as a design guide and review the result yourself.
