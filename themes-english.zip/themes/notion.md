---
name: design-theme
description: Notion-inspired teaching guide for UI styling, CSS, and design work. Apply this light-mode theme when styling the course project.
---

# Notion-Inspired Student Design Theme

This is an English teaching adaptation for the course, not an official Notion design specification. Keep the app's own name and content. Do not add brand logos or imply endorsement.

## Design direction

Warm, calm, and content-focused. A paper-like canvas, compact rounded corners, and clear information hierarchy should make the app feel like a useful workspace.

Use flat surfaces and small rounded corners. Prefer clear spacing and headings to decorative icons. Do not reproduce Notion logos or claim that these colors are official Notion specifications.

## Light-mode color tokens

| CSS token | Value | Use |
| --- | --- | --- |
| `--background` | `#F7F7F5` | Page background |
| `--surface` | `#FFFFFF` | Cards and containers |
| `--text` | `#37352F` | Primary text |
| `--text-sub` | `#64635F` | Secondary text |
| `--placeholder` | `#64635F` | Input placeholder text |
| `--border` | `#DEDEDA` | Decorative dividers and card borders |
| `--input-border` | `#77756F` | Visible form/control boundary |
| `--accent` | `#1F6B8F` | Primary action background |
| `--accent-hover` | `#185574` | Primary action hover background |
| `--on-accent` | `#FFFFFF` | Primary action text |
| `--link` | `#1F6B8F` | Inline links and tinted-control text |
| `--accent-soft` | `#EAF3F7` | Tinted secondary surfaces |
| `--focus` | `#185574` | Focus indicator |
| `--disabled-bg` | `#E7E7E3` | Disabled controls |
| `--error` | `#A92525` | Error text and indicator |
| `--success` | `#226B52` | Success text and indicator |

Use `--on-accent` on both the default and hover primary-button backgrounds. Use `--link` for links on light surfaces. The bright accent is not automatically a suitable text or focus color.

## Typography

- Font stack: `-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`.
- Main heading (`h1`): 30px, weight 700, line-height 1.25.
- Section heading (`h2`): 20px, weight 600, line-height 1.4.
- Body: 16px, weight 400, line-height 1.6.
- Brief metadata and badge text: 14px, line-height 1.5, using a readable secondary color.
- Form labels: at least 16px, weight 500 or 600. Never use placeholder text as the only label.
- Body links: use the link color and an underline; make hover and focus clearly visible without reducing opacity.

## Layout

- Preferred reading/form width: 720px, centered within its available column.
- Page horizontal padding: 24px on larger screens; at least 16px on phones.
- Top content spacing: 40px after accounting for the header.
- Section gap: 32px; related-element gap: 16px.
- Keep the existing app's header, sidebar, routes, and responsive grid. Follow the dashboard exception in the implementation rules below.

## Components

### Cards

Use white surfaces, a 1px decorative border, an 8px radius, and 16px padding. Do not use shadows. Clickable cards may change to a warm pale gray on hover and keyboard focus.

### Buttons

Use a 6px radius, 10px 16px padding, 16px text, and at least 44px height. Primary buttons use the blue accent with white text. Secondary buttons use primary text on white with the input-border color so their shape remains visible.

Use the accent-hover token on hover, preserve the on-accent text, and keep a separate visible focus ring. Disabled buttons use the disabled background and secondary text with no hover animation.

### Inputs and selects

Use a white background, a 1px input-border, a 6px radius, 10px 12px padding, and 16px text. Keep labels visible above fields. Show an error border and an accompanying text message when validation fails.

Style selects consistently with inputs, retain a recognizable dropdown indicator, and preserve native keyboard behavior. If an icon overlaps the right side, leave enough text padding for it.

### Badges and tags

Use a warm neutral background, primary text, a 4px radius, 4px 8px padding, and 14px text. Use labels such as "Course Notes" or "Research".

### Lists

Use subtle dividers, 12px vertical padding, and a warm-gray hover background. Give each item a clear title and a separate secondary description. Avoid adding a card around every short line.

### Navigation

Use a 56px minimum-height sticky header with 16-24px horizontal padding, a solid light surface, and a 16px semibold project title. A sidebar may use the warm page background while the main content remains white.

### Motion

Use 150ms ease transitions for background, border, and color. Keep hover and focus changes gentle; do not animate layout or add bounce effects.

## English sample content

Organize the bookmark app into "All Links", "Class Notes", and "Research". Keep descriptions readable and let the content lead.

Keep sample data fictional. Use clear US English and the course project's own terminology. Keep "Add Link" and "Add Folder" consistent across navigation, buttons, and dialogs.

## Accessibility and behavior

- Keep body copy, form inputs, and button labels at least 16px. The smaller 14px size is for brief metadata and badges only, not instructions or essential form labels.
- Target at least 4.5:1 contrast for normal text, including secondary text and placeholders. Use at least 3:1 for meaningful control boundaries, icons, and focus indicators against adjacent surfaces. Decorative dividers may be lighter. Recheck contrast if a token or background changes.
- Keep keyboard focus visible on every interactive element. In `globals.css`, use a 3px solid `var(--focus)` outline with a 3px offset for `:focus-visible`. Ensure it is not clipped by a card, header, or modal. On a colored surface, add a white separation ring if needed.
- Use native buttons, links, inputs, and selects where possible. A button performs an action; a link navigates. Give icon-only buttons an accessible name. Use at least 44px by 44px pointer targets with enough space between them.
- Underline links in body text. For navigation, make the current item clear with shape, text weight, or a marker as well as color. Essential controls must work with keyboard and touch; do not reveal them only on hover.
- Give fields persistent labels. Link validation messages to their fields with `aria-describedby` and mark invalid fields with `aria-invalid`. Never rely on color alone for errors, success, or selected states.
- For disabled controls, use the disabled background and secondary text instead of fading the entire component with opacity. Use the actual `disabled` attribute when appropriate and explain why an action is unavailable.
- Preserve meaningful heading order and visible labels. At 200% zoom, text must reflow without horizontal scrolling or overlapping controls. A fixed or sticky header must not cover content, focus targets, or anchor destinations.
- Respect `prefers-reduced-motion: reduce`: remove scaling and nonessential movement and shorten transitions. Animate only the specific properties that need to change, not `transition: all`.

## Implementation rules

1. Implement light mode only. Set `color-scheme: light` on the root. Do not add a dark palette, automatic dark-mode media query, or `.dark` theme. This keeps the course exercise consistent.
2. Define the table's tokens as CSS custom properties in the project's existing `app/globals.css` or `src/app/globals.css`. Reuse the existing file and import rather than creating a second global stylesheet.
3. Use one styling approach: Tailwind utility classes referencing those tokens, such as `bg-[var(--surface)]`, `text-[var(--text)]`, and `border-[var(--input-border)]`. Use global CSS for token definitions, base styles, shared states, and motion preferences. Do not mix in inline `style` objects for the same theme properties or add a new styling library.
4. Define hover, focus, and active visual states as CSS classes or pseudo-classes in `globals.css`. CSS hover effects work in both Server and Client Components and do not require JavaScript mouse handlers. Use the appropriate `.card-hover:hover` and `.card-hover:focus-visible` states only on genuinely interactive cards.
5. Keep Server Components as the default. Put browser interaction, state, and event handlers such as `onClick` or `onChange` inside the smallest necessary component with `"use client"`. A Server Component may render that Client Component and pass serializable data to it, but must not pass an ordinary browser-event callback across the server/client boundary.
6. Server Actions/Functions and Route Handlers run on the server; they are not browser event handlers. A supported Server Function may be invoked through an appropriate client or form integration. Keep existing server operations, secrets, and database code on the server. Do not mark the whole application `"use client"` to make a hover effect work.
7. Style the existing app without replacing its content, routes, folder/link behavior, validation, or database connections. Preserve component reuse. A theme request is not a request to add accounts, payments, tracking, external services, or new product features.
8. Treat the preferred content width as a reading width, not a mandate to squeeze an existing dashboard. Preserve required header/sidebar/grid layouts. On larger screens the full app may use an approximately 1120px shell; the main column can contain the narrower reading or form content. On phones, use one column with at least 16px side padding and no horizontal overflow.

## Review before finishing

- Check the main page, folder page, new-link form, and any existing modals at narrow and wide widths.
- Use Tab, Shift+Tab, Enter, and Escape where applicable. Confirm visible focus, meaningful labels, and working existing behavior.
- Verify body text, action text, placeholders, hover states, and error states remain readable. Check that the chosen theme is consistently applied.
- Report the components and stylesheet changed, explain how the tokens were applied, and identify any checks that could not be completed.
